// src/bot/admin/users/performance.js

const { Markup } = require("telegraf");
const pool = require("../../../db/pool");

// Состояния для создания/редактирования пользовательских элементов аттестации
// key: tg_id, value: { step, candidateId, itemId?, tempTitle?, tempType? }
const perfStates = new Map();

function setState(tgId, state) {
  perfStates.set(tgId, state);
}
function clearState(tgId) {
  perfStates.delete(tgId);
}

async function ensureDefaultAttestationItems() {
  // Дефолтные элементы должны существовать и быть не удаляемыми (is_default = true)
  // order_index: 1..3, далее пользовательские/академические
  const defaults = [
    { title: "📖 техкарта", order_index: 1 },
    { title: "📘 теория база", order_index: 2 },
    { title: "📕 теория продвинутый", order_index: 3 },
  ];

  // Вставляем только если отсутствует элемент с is_default=true и таким order_index
  // (title — для удобства читаемости)
  for (const d of defaults) {
    // eslint-disable-next-line no-await-in-loop
    await pool.query(
      `INSERT INTO attestation_items (title, order_index, is_active, is_default)
       SELECT $1, $2, TRUE, TRUE
       WHERE NOT EXISTS (
         SELECT 1 FROM attestation_items WHERE is_default = TRUE AND order_index = $2
       )`,
      [d.title, d.order_index]
    );
  }

  // На всякий случай фиксируем порядок/заголовки дефолтов (если кто-то их "переименовал")
  // Дефолты могут быть только выключены, но не переименованы.
  for (const d of defaults) {
    // eslint-disable-next-line no-await-in-loop
    await pool.query(
      `UPDATE attestation_items
       SET title = $1
       WHERE is_default = TRUE AND order_index = $2`,
      [d.title, d.order_index]
    );
  }
}

function modeTitle(mode) {
  if (mode === "attest") return "🏅 Аттестация";
  if (mode === "tests") return "📊 Тесты";
  return "📊 Успеваемость";
}

async function showPerformanceHome(ctx, candidateId, edit = true) {
  const text = `${modeTitle("home")}\n\nВыбери раздел:`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback("🏅 аттестация", `lk_perf_attest_${candidateId}`)],
    [Markup.button.callback("📊 тесты", `lk_perf_tests_${candidateId}`)],
    [
      Markup.button.callback(
        "🌱 данные стажировок",
        `lk_internship_data_${candidateId}`
      ),
    ],
    [Markup.button.callback("⬅️ Назад к карточке", `lk_cards_switch_trainee_${candidateId}`)],
  ]);

  if (edit) {
    await ctx.editMessageText(text, keyboard).catch(async () => {
      await ctx.reply(text, keyboard);
    });
  } else {
    await ctx.reply(text, keyboard);
  }
}

async function showTestsStub(ctx, candidateId) {
  const text = `📊 Тесты\n\nДанные по тестам добавим позже.`;
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback("⬅️ Назад", `lk_perf_home_${candidateId}`)],
  ]);
  await ctx.editMessageText(text, keyboard).catch(async () => {
    await ctx.reply(text, keyboard);
  });
}

async function fetchAttestationItemsForMenu() {
  const res = await pool.query(
    `SELECT id, title, order_index, is_active, COALESCE(is_default, FALSE) AS is_default
     FROM attestation_items
     ORDER BY order_index, id`
  );
  return res.rows;
}

async function showAttestMenu(ctx, candidateId) {
  await ensureDefaultAttestationItems();

  const items = await fetchAttestationItemsForMenu();

  let text = "✅ Элементы аттестации:\n\n";
  const buttons = [];

  for (const row of items) {
    const icon = row.is_active ? "✅" : "🚫";
    // В меню показываем все элементы, но дефолтные должны быть первыми (order_index 1..3)
    text += `${icon} [${row.order_index}] ${row.title}\n`;
    buttons.push([
      Markup.button.callback(
        `${icon} ${row.title}`,
        `lk_perf_attest_item_${candidateId}_${row.id}`
      ),
    ]);
  }

  buttons.push([Markup.button.callback("➕ Новый элемент", `lk_perf_attest_new_${candidateId}`)]);
  buttons.push([Markup.button.callback("⬅️ Назад", `lk_perf_home_${candidateId}`)]);

  await ctx
    .editMessageText(text, Markup.inlineKeyboard(buttons))
    .catch(async () => {
      await ctx.reply(text, Markup.inlineKeyboard(buttons));
    });
}

async function getAttestItem(itemId) {
  const res = await pool.query(
    `SELECT id,
            title,
            description,
            is_active,
            order_index,
            COALESCE(is_default, FALSE) AS is_default,
            COALESCE(item_type, 'normal') AS item_type,
            example_url
     FROM attestation_items
     WHERE id = $1`,
    [itemId]
  );
  return res.rows[0] || null;
}

function typeLabel(t) {
  if (t === "photo") return "фото";
  if (t === "video") return "видео";
  return "обычный";
}

async function showAttestItem(ctx, candidateId, itemId) {
  const row = await getAttestItem(itemId);
  if (!row) {
    await ctx.reply("Элемент аттестации не найден.");
    return;
  }

  const statusText = row.is_active ? "Активен ✅" : "Скрыт 🚫";

  let text =
    `✅ Элемент аттестации\n\n` +
    `Название: ${row.title}\n` +
    `Статус: ${statusText}`;

  if (!row.is_default) {
    text += `\nТип: ${typeLabel(row.item_type)}`;
  }

  if (!row.is_default && row.description) {
    text += `\n\nОписание:\n${row.description}`;
  } else if (row.is_default) {
    // для дефолтных — описание не выводим
  }

  const kb = [];

  if (row.is_default) {
    kb.push([Markup.button.callback("👁 Вкл/Выкл", `lk_perf_attest_toggle_${candidateId}_${row.id}`)]);
    kb.push([Markup.button.callback("⬅️ Назад", `lk_perf_attest_${candidateId}`)]);
  } else {
    kb.push([Markup.button.callback("✏️ Название", `lk_perf_attest_rename_${candidateId}_${row.id}`)]);
    kb.push([Markup.button.callback("📝 Описание", `lk_perf_attest_desc_${candidateId}_${row.id}`)]);
    kb.push([Markup.button.callback("🔘 Тип", `lk_perf_attest_type_${candidateId}_${row.id}`)]);

    if (row.item_type === "photo") {
      kb.push([Markup.button.callback("🖼 пример фото", `lk_perf_attest_example_${candidateId}_${row.id}`)]);
    }
    if (row.item_type === "video") {
      kb.push([Markup.button.callback("🎬 пример видео", `lk_perf_attest_example_${candidateId}_${row.id}`)]);
    }

    kb.push([Markup.button.callback("👁 Вкл/Выкл", `lk_perf_attest_toggle_${candidateId}_${row.id}`)]);
    kb.push([Markup.button.callback("🗑 Удалить", `lk_perf_attest_delete_${candidateId}_${row.id}`)]);
    kb.push([Markup.button.callback("⬅️ Назад", `lk_perf_attest_${candidateId}`)]);
  }

  await ctx
    .editMessageText(text, Markup.inlineKeyboard(kb))
    .catch(async () => {
      await ctx.reply(text, Markup.inlineKeyboard(kb));
    });
}

async function showTypePicker(ctx, candidateId, itemId, backAction) {
  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback("обычный", `lk_perf_attest_type_set_${candidateId}_${itemId}_normal`),
      Markup.button.callback("фото", `lk_perf_attest_type_set_${candidateId}_${itemId}_photo`),
      Markup.button.callback("видео", `lk_perf_attest_type_set_${candidateId}_${itemId}_video`),
    ],
    [Markup.button.callback("⬅️ Назад", backAction)],
  ]);

  await ctx
    .editMessageText("Выбери тип элемента:", kb)
    .catch(async () => {
      await ctx.reply("Выбери тип элемента:", kb);
    });
}

function registerPerformance(bot, ensureUser, logError, deliver) {
  // Главный вход (ранее был stub в candidateCard.js)
  bot.action(/^lk_intern_progress_stub_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      await ctx.answerCbQuery().catch(() => {});
      clearState(ctx.from.id);
      await showPerformanceHome(ctx, candidateId, true);
    } catch (err) {
      logError("lk_perf_home_entry", err);
    }
  });

  bot.action(/^lk_perf_home_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      await ctx.answerCbQuery().catch(() => {});
      clearState(ctx.from.id);
      await showPerformanceHome(ctx, candidateId, true);
    } catch (err) {
      logError("lk_perf_home", err);
    }
  });

  // Тесты (заглушка)
  bot.action(/^lk_perf_tests_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      await ctx.answerCbQuery().catch(() => {});
      clearState(ctx.from.id);
      await showTestsStub(ctx, candidateId);
    } catch (err) {
      logError("lk_perf_tests", err);
    }
  });

  // Аттестация меню
  bot.action(/^lk_perf_attest_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      await ctx.answerCbQuery().catch(() => {});
      clearState(ctx.from.id);
      await showAttestMenu(ctx, candidateId);
    } catch (err) {
      logError("lk_perf_attest_menu", err);
    }
  });

  // Открыть элемент аттестации
  bot.action(/^lk_perf_attest_item_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      clearState(ctx.from.id);
      await showAttestItem(ctx, candidateId, itemId);
    } catch (err) {
      logError("lk_perf_attest_item", err);
    }
  });

  // Toggle active
  bot.action(/^lk_perf_attest_toggle_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      await pool.query(
        "UPDATE attestation_items SET is_active = NOT is_active WHERE id = $1",
        [itemId]
      );
      await showAttestItem(ctx, candidateId, itemId);
    } catch (err) {
      logError("lk_perf_attest_toggle", err);
    }
  });

  // Создание нового элемента
  bot.action(/^lk_perf_attest_new_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      await ctx.answerCbQuery().catch(() => {});
      setState(ctx.from.id, { step: "new_title", candidateId });
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback("⬅️ Назад", `lk_perf_attest_${candidateId}`)],
      ]);
      await ctx
        .editMessageText("✏️ Введи название нового элемента одним сообщением:", kb)
        .catch(async () => {
          await ctx.reply("✏️ Введи название нового элемента одним сообщением:", kb);
        });
    } catch (err) {
      logError("lk_perf_attest_new", err);
    }
  });

  // Редактирование названия
  bot.action(/^lk_perf_attest_rename_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) return;
      setState(ctx.from.id, { step: "rename", candidateId, itemId });
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback("⬅️ Назад", `lk_perf_attest_item_${candidateId}_${itemId}`)],
      ]);
      await ctx
        .editMessageText("✏️ Введи новое название одним сообщением:", kb)
        .catch(async () => {
          await ctx.reply("✏️ Введи новое название одним сообщением:", kb);
        });
    } catch (err) {
      logError("lk_perf_attest_rename", err);
    }
  });

  // Редактирование описания
  bot.action(/^lk_perf_attest_desc_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) return;
      setState(ctx.from.id, { step: "desc", candidateId, itemId });
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback("⬅️ Назад", `lk_perf_attest_item_${candidateId}_${itemId}`)],
      ]);
      await ctx
        .editMessageText(
          "📝 Отправь описание одним сообщением (оно перезапишет текущее):",
          kb
        )
        .catch(async () => {
          await ctx.reply(
            "📝 Отправь описание одним сообщением (оно перезапишет текущее):",
            kb
          );
        });
    } catch (err) {
      logError("lk_perf_attest_desc", err);
    }
  });

  // Выбор типа (экран)
  bot.action(/^lk_perf_attest_type_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) return;
      await showTypePicker(
        ctx,
        candidateId,
        itemId,
        `lk_perf_attest_item_${candidateId}_${itemId}`
      );
    } catch (err) {
      logError("lk_perf_attest_type", err);
    }
  });

  // Установка типа
  bot.action(/^lk_perf_attest_type_set_(\d+)_(\d+)_(normal|photo|video)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      const t = ctx.match[3];
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) return;
      await pool.query(
        `UPDATE attestation_items
         SET item_type = $1,
             example_url = CASE WHEN $1 IN ('photo','video') THEN example_url ELSE NULL END
         WHERE id = $2`,
        [t, itemId]
      );
      await showAttestItem(ctx, candidateId, itemId);
    } catch (err) {
      logError("lk_perf_attest_type_set", err);
    }
  });

  // Пример (ввод)
  bot.action(/^lk_perf_attest_example_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) return;

      const what = row.item_type === "photo" ? "фото" : "видео";
      setState(ctx.from.id, { step: "example", candidateId, itemId });
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback("Пропустить", `lk_perf_attest_item_${candidateId}_${itemId}`)],
        [Markup.button.callback("⬅️ Назад", `lk_perf_attest_item_${candidateId}_${itemId}`)],
      ]);
      await ctx
        .editMessageText(
          `Отправь ссылку на пример ${what} одним сообщением (или "-" чтобы убрать/пропустить).`,
          kb
        )
        .catch(async () => {
          await ctx.reply(
            `Отправь ссылку на пример ${what} одним сообщением (или "-" чтобы убрать/пропустить).`,
            kb
          );
        });
    } catch (err) {
      logError("lk_perf_attest_example", err);
    }
  });

  // Удаление (только не-дефолт)
  bot.action(/^lk_perf_attest_delete_(\d+)_(\d+)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const itemId = Number(ctx.match[2]);
      await ctx.answerCbQuery().catch(() => {});
      const row = await getAttestItem(itemId);
      if (!row || row.is_default) {
        await ctx.answerCbQuery("Этот элемент нельзя удалить.", { show_alert: false }).catch(() => {});
        return;
      }
      await pool.query("DELETE FROM attestation_items WHERE id = $1", [itemId]);
      clearState(ctx.from.id);
      await showAttestMenu(ctx, candidateId);
    } catch (err) {
      logError("lk_perf_attest_delete", err);
    }
  });

  // Текстовые шаги (создание/редактирование)
  bot.on("text", async (ctx, next) => {
    try {
      const state = perfStates.get(ctx.from.id);
      if (!state) return next();

      const text = (ctx.message.text || "").trim();
      if (!text) return next();

      if (state.step === "new_title") {
        const candidateId = state.candidateId;
        // сохраняем название и просим выбрать тип
        setState(ctx.from.id, {
          step: "new_type",
          candidateId,
          tempTitle: text,
        });

        await showTypePicker(ctx, candidateId, 0, `lk_perf_attest_${candidateId}`);
        return;
      }

      if (state.step === "rename") {
        await pool.query("UPDATE attestation_items SET title = $1 WHERE id = $2", [text, state.itemId]);
        clearState(ctx.from.id);
        await showAttestItem(ctx, state.candidateId, state.itemId);
        return;
      }

      if (state.step === "desc") {
        await pool.query("UPDATE attestation_items SET description = $1 WHERE id = $2", [text, state.itemId]);
        clearState(ctx.from.id);
        await showAttestItem(ctx, state.candidateId, state.itemId);
        return;
      }

      if (state.step === "example") {
        const value = text === "-" ? null : text;
        await pool.query("UPDATE attestation_items SET example_url = $1 WHERE id = $2", [value, state.itemId]);
        clearState(ctx.from.id);
        await showAttestItem(ctx, state.candidateId, state.itemId);
        return;
      }

      return next();
    } catch (err) {
      logError("perf_text_handler", err);
      return next();
    }
  });

  // Специальный обработчик выбора типа при создании
  bot.action(/^lk_perf_attest_type_set_(\d+)_0_(normal|photo|video)$/, async (ctx) => {
    try {
      const candidateId = Number(ctx.match[1]);
      const t = ctx.match[2];
      await ctx.answerCbQuery().catch(() => {});

      const state = perfStates.get(ctx.from.id);
      if (!state || state.step !== "new_type" || state.candidateId !== candidateId) {
        await showAttestMenu(ctx, candidateId);
        return;
      }

      // вставляем новый элемент
      const insertRes = await pool.query(
        `INSERT INTO attestation_items (title, order_index, is_active, is_default, item_type)
         VALUES (
           $1,
           COALESCE((SELECT MAX(order_index)+1 FROM attestation_items), 1),
           TRUE,
           FALSE,
           $2
         )
         RETURNING id`,
        [state.tempTitle, t]
      );
      const itemId = insertRes.rows[0].id;
      clearState(ctx.from.id);

      // пример не обязателен — сразу открываем элемент
      await showAttestItem(ctx, candidateId, itemId);
    } catch (err) {
      logError("perf_new_type_set", err);
    }
  });
}

module.exports = registerPerformance;
