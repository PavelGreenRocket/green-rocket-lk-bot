// src/bot/tasks/today.js
const { Markup } = require("telegraf");
const pool = require("../../db/pool");
const { deliver } = require("../../utils/renderHelpers");
const { hasForCurrentShift } = require("../handover");

const { getUserState, setUserState, clearUserState } = require("../state");

const MODE = "lk_task_answer";

function getTaskState(tgId) {
  const st = getUserState(tgId);
  return st && st.mode === MODE ? st : null;
}

function setTaskState(tgId, patch) {
  const prev = getTaskState(tgId) || { mode: MODE, step: "idle" };
  setUserState(tgId, { ...prev, ...patch });
}

function clearTaskState(tgId) {
  const st = getTaskState(tgId);
  if (st) clearUserState(tgId);
}

// weekday bit: Mon=1<<0 ... Sun=1<<6
function weekdayBit(d) {
  const js = d.getDay(); // 0=Sun..6=Sat
  if (js === 0) return 1 << 6; // Sun
  return 1 << (js - 1); // Mon->0 ... Sat->5
}

async function dbTodayISO() {
  const r = await pool.query(`SELECT CURRENT_DATE::text AS d`);
  return r.rows[0]?.d || new Date().toISOString().slice(0, 10);
}

function toISODate(v) {
  if (!v) return null;

  if (typeof v === "string") return v.slice(0, 10);

  // ВАЖНО: не toISOString() (UTC может сместить дату)
  if (v instanceof Date) {
    const y = v.getFullYear();
    const m = String(v.getMonth() + 1).padStart(2, "0");
    const d = String(v.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  return String(v).slice(0, 10);
}

async function getActiveShiftForUser(userId) {
  const res = await pool.query(
    `
      SELECT id, trade_point_id
      FROM shifts
      WHERE user_id = $1
        AND opened_at::date = CURRENT_DATE
        AND status IN ('opening_in_progress','opened')
      ORDER BY opened_at DESC
      LIMIT 1
    `,
    [userId]
  );
  return res.rows[0] || null;
}

function scheduleMatchesToday(row, today, todayDateObj) {
  if (row.schedule_type === "single") {
    return toISODate(row.single_date) === today;
  }
  if (row.schedule_type === "weekly") {
    const bit = weekdayBit(todayDateObj);
    const mask = Number(row.weekdays_mask || 0);
    return (mask & bit) !== 0;
  }
  if (row.schedule_type === "every_x_days") {
    const x = Number(row.every_x_days || 0);
    if (!x || !row.start_date) return false;

    const startISO = toISODate(row.start_date);
    if (!startISO) return false;

    const start = new Date(startISO + "T00:00:00");
    const diffMs = todayDateObj.getTime() - start.getTime();
    const diffDays = Math.floor(diffMs / (24 * 3600 * 1000));
    return diffDays >= 0 && diffDays % x === 0;
  }
  return false;
}

function escHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function ensureTodayInstances(user, shift, today) {
  const todayObj = new Date(today + "T00:00:00");

  // schedule move overrides (skip/include for this date)
  let ovSkip = new Set();
  let ovInclude = new Set();
  try {
    if (shift?.trade_point_id) {
      // ensure table exists (safe)
      await pool.query(`
        CREATE TABLE IF NOT EXISTS task_schedule_overrides (
          assignment_id bigint NOT NULL REFERENCES task_assignments(id) ON DELETE CASCADE,
          trade_point_id bigint NOT NULL REFERENCES trade_points(id) ON DELETE CASCADE,
          from_date date NOT NULL,
          to_date date NOT NULL,
          created_at timestamptz NOT NULL DEFAULT now(),
          PRIMARY KEY (assignment_id, trade_point_id, from_date)
        )
      `);

      const ov = await pool.query(
        `SELECT assignment_id, from_date::text AS from_date, to_date::text AS to_date
         FROM task_schedule_overrides
         WHERE trade_point_id = $1 AND (from_date = $2::date OR to_date = $2::date)`,
        [Number(shift.trade_point_id), today]
      );

      for (const row of ov.rows) {
        const aid = Number(row.assignment_id);
        if (!aid) continue;
        if (row.from_date === today) ovSkip.add(aid);
        if (row.to_date === today) ovInclude.add(aid);
      }
    }
  } catch (_) {}

  // targets for individual
  const tgtRes = await pool.query(
    `SELECT assignment_id FROM task_assignment_targets WHERE user_id = $1`,
    [user.id]
  );
  const targetSet = new Set(tgtRes.rows.map((r) => Number(r.assignment_id)));

  // load active assignments + schedules + templates
  const asgRes = await pool.query(
    `
      SELECT
        a.id AS assignment_id,
        a.task_type,
        a.template_id,
        a.point_scope,
        a.trade_point_id,
        s.schedule_type,
        s.start_date,
        s.single_date,
        s.weekdays_mask,
        s.every_x_days,
        s.time_mode,
        s.deadline_time,
        t.title,
        t.answer_type
      FROM task_assignments a
      JOIN task_schedules s ON s.assignment_id = a.id
      JOIN task_templates t ON t.id = a.template_id
      WHERE a.is_active = TRUE
    `
  );

  for (const row of asgRes.rows) {
    const assignmentId = Number(row.assignment_id);

    // individual filter
    if (row.task_type === "individual" && !targetSet.has(assignmentId))
      continue;

    // point filter
    if (row.point_scope === "one_point") {
      if (!shift?.trade_point_id) continue;
      if (Number(row.trade_point_id) !== Number(shift.trade_point_id)) continue;
    }

    // schedule filter + overrides
    if (shift?.trade_point_id) {
      if (ovSkip.has(assignmentId)) continue;
      if (
        !ovInclude.has(assignmentId) &&
        !scheduleMatchesToday(row, today, todayObj)
      )
        continue;
    } else {
      if (!scheduleMatchesToday(row, today, todayObj)) continue;
    }

    // create instance if not exists
    await pool.query(
      `
        INSERT INTO task_instances
          (assignment_id, template_id, user_id, trade_point_id, for_date, time_mode, deadline_at, status)
        VALUES
          ($1, $2, $3, $4, $5, $6, NULL, 'open')
        ON CONFLICT (assignment_id, user_id, for_date) DO NOTHING
      `,
      [
        assignmentId,
        Number(row.template_id),
        user.id,
        shift?.trade_point_id || null,
        today,
        row.time_mode || "all_day",
      ]
    );
  }
}

async function loadTodayInstances(user, today) {
  const res = await pool.query(
    `
      SELECT
        ti.id,
        ti.status,
        ti.time_mode,
        ti.deadline_at,
        tt.title,
        tt.answer_type
      FROM task_instances ti
      JOIN task_templates tt ON tt.id = ti.template_id
      WHERE ti.user_id = $1
        AND ti.for_date = $2
      ORDER BY
        (ti.status = 'done') ASC,
        (ti.deadline_at IS NULL) ASC,
        ti.deadline_at NULLS LAST,
        ti.id ASC
    `,
    [user.id, today]
  );
  return res.rows;
}

function buildTasksText(rows) {
  let text = "📋 <b>Задачи на сегодня</b>\n\n";
  if (!rows.length) {
    text += "На сегодня задач нет ✅";
    return text;
  }

  rows.forEach((r, idx) => {
    const n = idx + 1;
    const done = r.status === "done";
    const title = escHtml(r.title || "Без названия");
    const line = done ? `✅ <s>${title}</s>` : `${n}. ${title}`;
    text += line + "\n";
  });

  return text;
}

function buildKeyboard(rows, hasComments) {
  const kb = [];

  if (rows.length) {
    const btns = rows.map((r, idx) => {
      const n = idx + 1;
      const done = r.status === "done";
      const label = done ? `✅${n}` : `${n}`;
      return Markup.button.callback(label, `lk_task_open_${r.id}`);
    });

    // по 5 кнопок в ряд, чтобы не было гигантской простыни
    for (let i = 0; i < btns.length; i += 5) kb.push(btns.slice(i, i + 5));
  }

  if (hasComments) {
    kb.push([
      Markup.button.callback("📝 Комментарии для вас", "lk_handover_view"),
    ]);
  }

  kb.push([Markup.button.callback("⬅️ В меню", "lk_main_menu")]);
  return Markup.inlineKeyboard(kb);
}

async function showTodayTasks(ctx, user) {
  const shift = await getActiveShiftForUser(user.id).catch(() => null);

  const today = await dbTodayISO();

  await ensureTodayInstances(user, shift, today);

  const rows = await loadTodayInstances(user, today);

  const text = buildTasksText(rows);

  const hasComments =
    !!shift?.trade_point_id &&
    !!shift?.id &&
    (await hasForCurrentShift(shift.trade_point_id, shift.id).catch(
      () => false
    ));

  const keyboard = buildKeyboard(rows, hasComments);

  // ✅ если пришли из кнопки — edit
  if (ctx.callbackQuery) {
    await deliver(ctx, { text, extra: keyboard }, { edit: true });
    return;
  }

  // ✅ если пришли из сообщения (наличка/ответы) — только reply
  await ctx.reply(text, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
}

function askForAnswerText(answerType, title) {
  if (answerType === "photo")
    return `📷 <b>${escHtml(
      title
    )}</b>\n\nПришлите <b>фото</b> для этой задачи.`;
  if (answerType === "video")
    return `🎥 <b>${escHtml(
      title
    )}</b>\n\nПришлите <b>видео</b> для этой задачи.`;
  if (answerType === "number")
    return `🔢 <b>${escHtml(title)}</b>\n\nВведите <b>число</b>.`;
  return `📝 <b>${escHtml(title)}</b>\n\nВведите <b>текст</b>.`;
}

async function markDoneWithAnswer(taskInstanceId, payload) {
  const { answerType } = payload;

  // ✅ заменяем предыдущий ответ (если был)
  await pool.query(
    `DELETE FROM task_instance_answers WHERE task_instance_id = $1`,
    [taskInstanceId]
  );

  // insert answer
  await pool.query(
    `
      INSERT INTO task_instance_answers
        (task_instance_id, answer_text, answer_number, file_id, file_type)
      VALUES
        ($1, $2, $3, $4, $5)
    `,
    [
      taskInstanceId,
      answerType === "text" ? payload.text : null,
      answerType === "number" ? payload.number : null,
      answerType === "photo" || answerType === "video" ? payload.fileId : null,
      answerType === "photo" || answerType === "video" ? answerType : null,
    ]
  );

  // mark done
  await pool.query(
    `
      UPDATE task_instances
      SET status = 'done', done_at = NOW()
      WHERE id = $1
    `,
    [taskInstanceId]
  );
}

async function notifyResponsiblesOnCompletion(bot, taskInstanceId) {
  try {
    // gather context
    const r = await pool.query(
      `
      SELECT
        ti.id AS task_instance_id,
        ti.assignment_id,
        ti.trade_point_id,
        tp.title AS point_title,
        tt.title AS task_title
      FROM task_instances ti
      JOIN task_assignments a ON a.id = ti.assignment_id
      JOIN task_templates tt ON tt.id = a.template_id
      LEFT JOIN trade_points tp ON tp.id = ti.trade_point_id
      WHERE ti.id = $1
      LIMIT 1
      `,
      [taskInstanceId]
    );
    const row = r.rows[0];
    if (!row) return;

    // respect completion notification setting (fallback: true)
    let completionEnabled = true;
    try {
      const s = await pool.query(
        `
        SELECT COALESCE(completion_notifications_enabled, TRUE) AS enabled
        FROM task_assignment_responsible_settings
        WHERE assignment_id = $1
        LIMIT 1
        `,
        [row.assignment_id]
      );
      completionEnabled = s.rows[0]?.enabled !== false;
    } catch (e) {
      completionEnabled = true;
    }
    if (!completionEnabled) return;

    const users = await pool.query(
      `
      SELECT u.telegram_id
      FROM task_assignment_responsibles ar
      JOIN users u ON u.id = ar.user_id
      WHERE ar.assignment_id = $1 AND u.telegram_id IS NOT NULL
      `,
      [row.assignment_id]
    );
    if (!users.rows.length) return;

    const ans = await pool.query(
      `
      SELECT answer_text, answer_number, file_id, file_type
      FROM task_instance_answers
      WHERE task_instance_id = $1
      ORDER BY id DESC
      LIMIT 1
      `,
      [taskInstanceId]
    );
    const a = ans.rows[0] || {};

    let caption = `✅ Задача выполнена\n\n`;
    caption += `Задача: ${row.task_title}\n`;
    if (row.point_title) caption += `Точка: ${row.point_title}\n`;
    if (a.answer_text) caption += `\nКомментарий: ${a.answer_text}`;
    if (typeof a.answer_number === "number")
      caption += `\nОтвет: ${a.answer_number}`;

    for (const u of users.rows) {
      const chatId = Number(u.telegram_id);
      if (!chatId) continue;
      try {
        if (a.file_id && a.file_type === "photo") {
          await bot.telegram.sendPhoto(chatId, a.file_id, { caption });
        } else if (a.file_id && a.file_type === "video") {
          await bot.telegram.sendVideo(chatId, a.file_id, { caption });
        } else {
          await bot.telegram.sendMessage(chatId, caption);
        }
      } catch (e) {
        // ignore per-user send errors
      }
    }
  } catch (e) {
    // ignore
  }
}

function registerTodayTasks(bot, ensureUser, logError) {
  // entry from menu
  bot.action("lk_tasks_today", async (ctx) => {
    try {
      const user = await ensureUser(ctx);
      if (!user) return;

      const staffStatus = user.staff_status || "worker";
      if (staffStatus === "candidate") {
        await ctx
          .answerCbQuery("Доступ появится после начала стажировки.", {
            show_alert: true,
          })
          .catch(() => {});
        return;
      }

      clearTaskState(ctx.from.id);
      await showTodayTasks(ctx, user);
    } catch (err) {
      logError("lk_tasks_today", err);
    }
  });

  // open task by number
  bot.action(/^lk_task_open_(\d+)$/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!user) return;

      const taskId = Number(ctx.match[1]);
      const res = await pool.query(
        `
          SELECT ti.id, ti.status, tt.title, tt.answer_type
          FROM task_instances ti
          JOIN task_templates tt ON tt.id = ti.template_id
          WHERE ti.id = $1 AND ti.user_id = $2
          LIMIT 1
        `,
        [taskId, user.id]
      );
      const row = res.rows[0];
      if (!row) {
        await ctx
          .answerCbQuery("Задача не найдена", { show_alert: true })
          .catch(() => {});
        return;
      }
      // ✅ "обычная" задача (button) — кликом отмечаем/снимаем выполнение
      if (row.answer_type === "button") {
        if (row.status === "done") {
          // отмена выполнения
          await pool.query(
            `
              UPDATE task_instances
              SET status = 'open', done_at = NULL
              WHERE id = $1
            `,
            [row.id]
          );

          await ctx.answerCbQuery("Отменено ↩️").catch(() => {});
          await showTodayTasks(ctx, user);
          return;
        }

        // отметить выполненной
        await pool.query(
          `
            UPDATE task_instances
            SET status = 'done', done_at = NOW()
            WHERE id = $1
          `,
          [row.id]
        );

        await ctx.answerCbQuery("Готово ✅").catch(() => {});
        await showTodayTasks(ctx, user);
        return;
      }

      // Для text/number/photo/video:
      // даже если задача уже "done", повторный клик НЕ отменяет,
      // а просто открывает ввод, чтобы заменить ответ.

      // switch to await answer
      setTaskState(ctx.from.id, {
        step: "await_answer",
        taskInstanceId: row.id,
        answerType: row.answer_type,
      });

      const text =
        askForAnswerText(row.answer_type, row.title) +
        "\n\n<i>Можно отправить новый ответ — он заменит предыдущий.</i>";

      const keyboard = Markup.inlineKeyboard([
        [{ text: "⬅️ Назад к задачам", callback_data: "lk_tasks_today" }],
        [{ text: "❌ Отмена", callback_data: "lk_task_answer_cancel" }],
      ]);

      await deliver(ctx, { text, extra: keyboard }, { edit: true });
      return;
    } catch (err) {
      logError("lk_task_open", err);
    }
  });

  bot.action("lk_task_answer_cancel", async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      clearTaskState(ctx.from.id);
      await deliver(
        ctx,
        {
          text: "Ок, отменено.",
          extra: Markup.inlineKeyboard([
            [{ text: "📋 Задачи", callback_data: "lk_tasks_today" }],
          ]),
        },
        { edit: true }
      );
    } catch (err) {
      logError("lk_task_answer_cancel", err);
    }
  });

  // handle TEXT/NUMBER answers
  bot.on("text", async (ctx, next) => {
    const st = getTaskState(ctx.from.id);
    if (!st || st.step !== "await_answer") return next();

    try {
      const user = await ensureUser(ctx);
      if (!user) return;

      const txt = (ctx.message.text || "").trim();
      if (!txt) return;

      if (st.answerType === "number") {
        const num = Number(txt.replace(",", "."));
        if (!Number.isFinite(num)) {
          await ctx.reply("❌ Нужно число. Пример: 12 или 12.5");
          return;
        }
        await markDoneWithAnswer(st.taskInstanceId, {
          answerType: "number",
          number: num,
        });
        await notifyResponsiblesOnCompletion(bot, st.taskInstanceId);
      } else if (st.answerType === "text") {
        await markDoneWithAnswer(st.taskInstanceId, {
          answerType: "text",
          text: txt,
        });
        await notifyResponsiblesOnCompletion(bot, st.taskInstanceId);
      } else {
        return next();
      }

      clearTaskState(ctx.from.id);
      await ctx.reply("✅ Принято!");
      // перерисуем список
      await showTodayTasks(ctx, user);
    } catch (err) {
      logError("lk_task_answer_text", err);
      await ctx.reply("❌ Не удалось сохранить ответ. Попробуйте ещё раз.");
    }
  });

  // handle PHOTO
  bot.on("photo", async (ctx, next) => {
    const st = getTaskState(ctx.from.id);
    if (!st || st.step !== "await_answer") return next();

    try {
      const user = await ensureUser(ctx);
      if (!user) return;

      if (st.answerType !== "photo") return next();

      const photos = ctx.message.photo || [];
      const best = photos[photos.length - 1];
      if (!best?.file_id) return next();

      await markDoneWithAnswer(st.taskInstanceId, {
        answerType: "photo",
        fileId: best.file_id,
      });

      await notifyResponsiblesOnCompletion(bot, st.taskInstanceId);

      clearTaskState(ctx.from.id);
      await ctx.reply("✅ Фото принято!");
      await showTodayTasks(ctx, user);
    } catch (err) {
      logError("lk_task_answer_photo", err);
      await ctx.reply("❌ Не удалось сохранить фото. Попробуйте ещё раз.");
    }
  });

  // handle VIDEO
  bot.on("video", async (ctx, next) => {
    const st = getTaskState(ctx.from.id);
    if (!st || st.step !== "await_answer") return next();

    try {
      const user = await ensureUser(ctx);
      if (!user) return;

      if (st.answerType !== "video") return next();

      const v = ctx.message.video;
      if (!v?.file_id) return next();

      await markDoneWithAnswer(st.taskInstanceId, {
        answerType: "video",
        fileId: v.file_id,
      });

      await notifyResponsiblesOnCompletion(bot, st.taskInstanceId);

      clearTaskState(ctx.from.id);
      await ctx.reply("✅ Видео принято!");
      await showTodayTasks(ctx, user);
    } catch (err) {
      logError("lk_task_answer_video", err);
      await ctx.reply("❌ Не удалось сохранить видео. Попробуйте ещё раз.");
    }
  });
}

module.exports = { registerTodayTasks, showTodayTasks };
