// src/utils/renderHelpers.js

/**
 * Универсальная функция отправки/обновления сообщений.
 *
 * Использование:
 *   await deliver(ctx, { text, extra }, { edit: true });
 *   await deliver(ctx, { text, extra }, { edit: false });
 *
 * extra — это обычный объект с reply_markup, parse_mode и т.п.
 */
async function deliver(ctx, payload, options = {}) {
  const { text, extra } = payload || {};
  const { edit = false } = options;

  if (!ctx) {
    throw new Error("deliver: ctx is required");
  }

  // Если нужно отредактировать существующее сообщение (обычно с callback_query)
  if (edit && (ctx.callbackQuery || ctx.updateType === "callback_query")) {
    try {
      return await ctx.editMessageText(text, { parse_mode: "HTML", ...extra });
    } catch (err) {
      const desc =
        err?.response?.description || err?.description || String(err || "");

      // ✅ Нормальная ситуация: пытаемся "перерисовать" то же самое
      if (desc.includes("message is not modified")) {
        return; // ничего не делаем и НЕ шлём новое сообщение
      }

      // Частые ошибки, когда текущее сообщение НЕ текст (например фото):
      // "Bad Request: there is no text in the message to edit"
      // также иногда: "message can't be edited", "message to edit not found"
      console.error("deliver: edit failed, fallback", err);

      const needDeleteAndReply =
        desc.includes("there is no text in the message to edit") ||
        desc.includes("message can't be edited") ||
        desc.includes("message to edit not found") ||
        desc.includes("MESSAGE_ID_INVALID");

      if (needDeleteAndReply) {
        try {
          await ctx.deleteMessage().catch(() => {});
        } catch (_) {}
      }

      try {
        return await ctx.reply(text, { parse_mode: "HTML", ...extra });
      } catch (err2) {
        console.error("deliver: reply after failed edit also failed", err2);
      }
    }
    return;
  }

  // Обычный режим — просто отправляем новое сообщение
  try {
    return await ctx.reply(text, { parse_mode: "HTML", ...(extra || {}) });
  } catch (err) {
    console.error("deliver: reply failed", err);
  }
}

module.exports = {
  deliver,
};
