// src/bot/reports/index.js
// Обёртка, чтобы внешний импорт остался прежним.
module.exports = require('./controller');
