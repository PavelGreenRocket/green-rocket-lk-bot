// src/bot/tasks/shiftDaily.js
function registerShiftDailyTasks(bot, ensureUser, logError) {
  // позже сюда: shift_tasks_today + чек-лист (1|2|3…)
}

module.exports = { registerShiftDailyTasks };
